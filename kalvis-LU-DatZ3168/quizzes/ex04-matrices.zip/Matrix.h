#ifndef DS_MATRIX_H
#define DS_MATRIX_H

#include "Ratio.h"
#include <iostream>
#include <iomanip>
#include <string>

extern std::string matrixType;


namespace ds_course
{
    template <class T>
    class Matrix
    {
    private:
        int rows; // row count
        int cols; // column count
    public:
        T **a;
        Matrix(int rr, int cc);
        int getRows();
        int getCols();

        ds_course::Matrix<T> operator+(const ds_course::Matrix<T> &r) {
            if (rows != r.rows) {
                throw std::out_of_range("ds_course::Matrix ADD: row counts are different");
            }
            if (cols != r.cols) {
                throw std::out_of_range("ds_course::Matrix ADD: column counts are different");
            }
            ds_course::Matrix<T> result(rows,cols);
            for (int i = 0; i < rows; i++) 
                for (int j = 0; j < cols; j++) 
                    result.a[i][j] = a[i][j] + r.a[i][j];
            return result;
        }

        ds_course::Matrix<T> operator-(const ds_course::Matrix<T> &r) {
            if (rows != r.rows) {
                throw std::out_of_range("ds_course::Matrix SUB: row counts are different");
            }
            if (cols != r.cols) {
                throw std::out_of_range("ds_course::Matrix SUB: column counts are different");
            }
            ds_course::Matrix<T> result(rows,cols);
            for (int i = 0; i < rows; i++) 
                for (int j = 0; j < cols; j++) 
                    result.a[i][j] = a[i][j] - r.a[i][j];
            return result;
        }


        ds_course::Matrix<T> operator*(const ds_course::Matrix<T> &r) {
            if (cols != r.rows) {
                throw std::out_of_range("ds_course::Matrix MUL: sizes do not allow multiplication");
            }
            //std::cerr << "Resulting product (" << rows << "," << r.cols << ")" << endl;
            ds_course::Matrix<T> result(rows,r.cols);
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < r.cols; j++) {
                    result.a[i][j] = 0;
                    for (int k = 0; k < cols; k++) {
                        
                        result.a[i][j] = result.a[i][j] + a[i][k] * r.a[k][j];
                    }
                }
            }

            return result;
        }        

        friend std::istream& operator>>(std::istream &input, ds_course::Matrix<T> &m) {
            for (int i = 0; i < m.getRows(); i++)
                for (int j = 0; j < m.getCols(); j++)
                    input >> m.a[i][j];                    
            return input;
        }

        friend std::ostream &operator<<(std::ostream &rOs, ds_course::Matrix<T> &m)
        {
            rOs << matrixType << " " << m.getRows() << " " << m.getCols() << "\n";
            for (int i = 0; i < m.getRows(); i++)
            {  
                std::string sep = "";
                for (int j = 0; j < m.getCols(); j++)
                {   
                    if (matrixType == "MR") {
                        //std::cerr << "Output fixed precision" << endl;
                        rOs << std::fixed << std::setprecision(5) << sep << m.a[i][j];
                    }
                    else {
                        rOs << sep << m.a[i][j];
                    }
                    sep = " ";
                }
                rOs << "\n";
            }
            return rOs;
        }
    };
} // namespace ds_course

//using namespace ds_course;
template <class T>
ds_course::Matrix<T>::Matrix(int rr, int cc) : rows(rr), cols(cc)
{
    a = new T *[rows];
    for (int i = 0; i < rows; i++)
    {
        a[i] = new T[cols];
    }
}

//Ratio::Ratio(int p0, int q0): p(p0), q(q0)  {}

template <class T>
int ds_course::Matrix<T>::getRows()
{
    return rows;
}

template <class T>
int ds_course::Matrix<T>::getCols()
{
    return cols;
}



#endif /* DS_MATRIX_H */
